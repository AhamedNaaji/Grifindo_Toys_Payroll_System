﻿namespace Grifindo_Toys_Payroll_System
{


    partial class Grifindo_Toys_Payroll_SystemDataSet
    {
    }
}
