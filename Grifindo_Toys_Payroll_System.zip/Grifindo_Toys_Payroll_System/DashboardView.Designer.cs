﻿namespace Grifindo_Toys_Payroll_System
{
    partial class DashboardView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardView));
            this.btnemployee = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAttendance = new System.Windows.Forms.Button();
            this.btnEmployeeType = new System.Windows.Forms.Button();
            this.btnleave = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnsalary = new System.Windows.Forms.Button();
            this.btnprintReport = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnemployee
            // 
            this.btnemployee.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnemployee.Font = new System.Drawing.Font("Poppins", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnemployee.ForeColor = System.Drawing.Color.Yellow;
            this.btnemployee.Location = new System.Drawing.Point(81, 128);
            this.btnemployee.Name = "btnemployee";
            this.btnemployee.Size = new System.Drawing.Size(637, 72);
            this.btnemployee.TabIndex = 23;
            this.btnemployee.Text = "Register Employee";
            this.btnemployee.UseVisualStyleBackColor = false;
            this.btnemployee.Click += new System.EventHandler(this.btnemployee_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Info;
            this.label1.Location = new System.Drawing.Point(196, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 48);
            this.label1.TabIndex = 29;
            this.label1.Text = "Dash - Board ";
            // 
            // btnAttendance
            // 
            this.btnAttendance.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnAttendance.Font = new System.Drawing.Font("Poppins", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAttendance.ForeColor = System.Drawing.Color.Yellow;
            this.btnAttendance.Location = new System.Drawing.Point(81, 248);
            this.btnAttendance.Name = "btnAttendance";
            this.btnAttendance.Size = new System.Drawing.Size(326, 72);
            this.btnAttendance.TabIndex = 28;
            this.btnAttendance.Text = "Attendance";
            this.btnAttendance.UseVisualStyleBackColor = false;
            this.btnAttendance.Click += new System.EventHandler(this.btnAttendance_Click_1);
            // 
            // btnEmployeeType
            // 
            this.btnEmployeeType.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnEmployeeType.Font = new System.Drawing.Font("Poppins", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployeeType.ForeColor = System.Drawing.Color.Yellow;
            this.btnEmployeeType.Location = new System.Drawing.Point(829, 140);
            this.btnEmployeeType.Name = "btnEmployeeType";
            this.btnEmployeeType.Size = new System.Drawing.Size(383, 58);
            this.btnEmployeeType.TabIndex = 27;
            this.btnEmployeeType.Text = "Employee Type";
            this.btnEmployeeType.UseVisualStyleBackColor = false;
            this.btnEmployeeType.Click += new System.EventHandler(this.btnEmployeeType_Click_1);
            // 
            // btnleave
            // 
            this.btnleave.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnleave.Font = new System.Drawing.Font("Poppins", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnleave.ForeColor = System.Drawing.Color.Yellow;
            this.btnleave.Location = new System.Drawing.Point(868, 250);
            this.btnleave.Name = "btnleave";
            this.btnleave.Size = new System.Drawing.Size(213, 72);
            this.btnleave.TabIndex = 26;
            this.btnleave.Text = "Leave";
            this.btnleave.UseVisualStyleBackColor = false;
            this.btnleave.Click += new System.EventHandler(this.btnleave_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSettings.Font = new System.Drawing.Font("Poppins", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettings.ForeColor = System.Drawing.Color.Yellow;
            this.btnSettings.Location = new System.Drawing.Point(512, 248);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(247, 72);
            this.btnSettings.TabIndex = 25;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = false;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click_1);
            // 
            // btnsalary
            // 
            this.btnsalary.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnsalary.Font = new System.Drawing.Font("Poppins", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsalary.ForeColor = System.Drawing.Color.Yellow;
            this.btnsalary.Location = new System.Drawing.Point(81, 368);
            this.btnsalary.Name = "btnsalary";
            this.btnsalary.Size = new System.Drawing.Size(796, 72);
            this.btnsalary.TabIndex = 24;
            this.btnsalary.Text = "Salary Calaculation";
            this.btnsalary.UseVisualStyleBackColor = false;
            this.btnsalary.Click += new System.EventHandler(this.btnsalary_Click);
            // 
            // btnprintReport
            // 
            this.btnprintReport.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnprintReport.Font = new System.Drawing.Font("Poppins", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprintReport.ForeColor = System.Drawing.Color.Yellow;
            this.btnprintReport.Location = new System.Drawing.Point(81, 473);
            this.btnprintReport.Name = "btnprintReport";
            this.btnprintReport.Size = new System.Drawing.Size(1131, 72);
            this.btnprintReport.TabIndex = 38;
            this.btnprintReport.Text = "Print Report";
            this.btnprintReport.UseVisualStyleBackColor = false;
            this.btnprintReport.Click += new System.EventHandler(this.btnprintReport_Click);
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Image = global::Grifindo_Toys_Payroll_System.Properties.Resources.number_7;
            this.label10.Location = new System.Drawing.Point(6, 473);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 70);
            this.label10.TabIndex = 39;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Image = global::Grifindo_Toys_Payroll_System.Properties.Resources.list;
            this.label9.Location = new System.Drawing.Point(94, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 70);
            this.label9.TabIndex = 37;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Image = global::Grifindo_Toys_Payroll_System.Properties.Resources.number_2;
            this.label8.Location = new System.Drawing.Point(741, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 70);
            this.label8.TabIndex = 36;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Image = global::Grifindo_Toys_Payroll_System.Properties.Resources.number_6;
            this.label7.Location = new System.Drawing.Point(6, 368);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 70);
            this.label7.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Image = global::Grifindo_Toys_Payroll_System.Properties.Resources.number_5;
            this.label6.Location = new System.Drawing.Point(790, 250);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 70);
            this.label6.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Image = global::Grifindo_Toys_Payroll_System.Properties.Resources.number_4;
            this.label5.Location = new System.Drawing.Point(434, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 70);
            this.label5.TabIndex = 33;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Image = global::Grifindo_Toys_Payroll_System.Properties.Resources.number_3;
            this.label3.Location = new System.Drawing.Point(3, 250);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 70);
            this.label3.TabIndex = 32;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Image = global::Grifindo_Toys_Payroll_System.Properties.Resources.number_1;
            this.label2.Location = new System.Drawing.Point(3, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 68);
            this.label2.TabIndex = 31;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Image = global::Grifindo_Toys_Payroll_System.Properties.Resources.Mainmenu;
            this.label4.Location = new System.Drawing.Point(3, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 70);
            this.label4.TabIndex = 30;
            // 
            // DashboardView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1227, 576);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btnprintReport);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnemployee);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAttendance);
            this.Controls.Add(this.btnEmployeeType);
            this.Controls.Add(this.btnleave);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.btnsalary);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DashboardView";
            this.Text = "DashboardView";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnemployee;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAttendance;
        private System.Windows.Forms.Button btnEmployeeType;
        private System.Windows.Forms.Button btnleave;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnsalary;
        private System.Windows.Forms.Button btnprintReport;
        private System.Windows.Forms.Label label10;
    }
}